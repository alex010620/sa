﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fm.Modelo
{
    public class Pedidos
    {
        public int IdOrden { get; set; }
        public int IdUsuarios { get; set; }
        public string Telefono { get; set; }
        public string Total { get; set; }
        public string Direccion { get; set; }
        public string Latitud { get; set; }
        public string Longitud { get; set; }
        public string Estado { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Correo { get; set; }
    }
}
