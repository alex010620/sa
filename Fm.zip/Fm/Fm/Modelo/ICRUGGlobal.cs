﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fm.Modelo
{
    interface ICRUGGlobal
    {
        Task<dynamic> Create(string objeto);
        Task<dynamic> Update(string id, string objeto);
        Task<dynamic> Delete(string id);
    }
}
