﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Fm.Modelo;
using Newtonsoft.Json;
namespace Fm.Data
{
    public class ConsumoDataPedidos
    {
        List<Pedidos> pedidos = new List<Pedidos>();
        public async Task<List<Pedidos>>   ObtenerDataPedido()
        {
            pedidos = new List<Pedidos>();
            Uri url = new Uri("https://super-mini-market.herokuapp.com/api/Seleccionar_Pedidos");
            WebClient client = new WebClient();
            var data = await client.DownloadStringTaskAsync(url);
            dynamic Datos = JsonConvert.DeserializeObject(data);
            foreach (var item in Datos?.data)
            {
                var pedido = new Pedidos
                {
                    IdOrden = item.IdOrden,
                    IdUsuarios = item.IdUsuarios,
                    Telefono = item.Telefono,
                    Total = item.Total,
                    Direccion = item.Direccion,
                    Latitud = item.Latitud,
                    Longitud = item.Longitud,
                    Estado = item.Estado,
                    Nombre = item.Nombre,
                    Apellido = item.Apellido,
                    Correo = item.Correo
                };
                pedidos.Add(pedido);
                Console.WriteLine(pedido);
            }
            return pedidos;
        }
    }
}
