﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Fm.Modelo;
using Newtonsoft.Json;

namespace Fm.Data
{
    public class ConsumoDataProductos
    {
        List<RootProductos> rootProductos = new List<RootProductos>();
        public async Task<List<RootProductos>> RootProductosAsync(string id)
        {
            rootProductos = new List<RootProductos>();
            Uri url = new Uri($"https://super-mini-market.herokuapp.com/api/get-producto-restaurantes/{id}");
            WebClient client = new WebClient();
            var data = await client.DownloadStringTaskAsync(url);
            dynamic Datos = JsonConvert.DeserializeObject(data);
            if (Datos.ok != false)
            {
                foreach (var item in Datos?.data)
                {
                    var productos = new RootProductos
                    {
                        IdProducto = item.IdProducto,
                        Nombre_producto = item.Nombre_producto,
                        Categoria_producto = item.Categoria_producto,
                        Foto_producto = item.Foto_producto,
                        Descripcion_producto = item.Descripcion_producto,
                        Stock = item.Stock,
                        Precio = item.Precio
                    };
                    rootProductos.Add(productos);
                }
                return rootProductos;
            }
            else
            {
               
                return null;
            }
            
        }
    }
}
