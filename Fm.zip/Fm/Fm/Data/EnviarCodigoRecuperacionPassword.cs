﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Configuration;
using System.Web;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
namespace Fm.Data
{
    public class EnviarCodigoRecuperacionPassword
    {
      
        public bool EnviarCorreo(string correouser, int codigo)
        {
            
            MailMessage correo = new MailMessage();
            correo.From = new MailAddress("for.foot.fusion@gmail.com", "for foot", System.Text.Encoding.UTF8);
            correo.To.Add(correouser);
            correo.Subject = "Codigo de verificacion";
            correo.Body = $"Saludos,\n\nTu codigo de verificacion es: {codigo}";
            correo.IsBodyHtml = true;
            correo.Priority = MailPriority.Normal;
            SmtpClient smtp = new SmtpClient();
            smtp.UseDefaultCredentials = false;
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;//True si el servidor de correo permite ssl
            smtp.Credentials = new System.Net.NetworkCredential("for.foot.fusion@gmail.com", "Forfoot9550");//Cuenta de correo
            ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            smtp.Send(correo);
            return true;
        }
    }
}
