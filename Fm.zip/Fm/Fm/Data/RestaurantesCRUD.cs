﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Fm.Modelo;
using Newtonsoft.Json;

namespace Fm.Data
{
    public class RestaurantesCRUD: ICRUGGlobal
    {
        List<RootRestaurantes> rootRestaurantes = new List<RootRestaurantes>();

        public async Task<dynamic> Create(string objeto)
        {
            Uri url = new Uri("https://super-mini-market.herokuapp.com/api/Registro_Restaurantes");
            WebClient client = new WebClient();
            var data = await client.UploadStringTaskAsync(url, objeto);
            dynamic valor = JsonConvert.DeserializeObject(data);
            return valor;
        }

        public Task<dynamic> Delete(string id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<RootRestaurantes>> GetSelect()
        {
            try
            {
                rootRestaurantes = new List<RootRestaurantes>();
                Uri url = new Uri("https://super-mini-market.herokuapp.com/api/get-restaurantes");
                WebClient client = new WebClient();
                var data = await client.DownloadStringTaskAsync(url);
                dynamic Datos = JsonConvert.DeserializeObject(data)!;
                foreach (var i in Datos.data)
                {
                    var datos = new RootRestaurantes
                    {
                        IdRestaurante = i.IdRestaurante,
                        Nombre = i.Nombre,
                        Telefono = i.Telefono,
                        Direccion = i.Direccion,
                        Foto = i.Foto,
                        Hora_apertura = i.Hora_apertura,
                        Hora_cierre = i.Hora_cierre,
                        Dias_laborables = i.Dias_laborables
                    };
                    rootRestaurantes.Add(datos);
                }
                return rootRestaurantes;

            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<List<RootRestaurantes>> GetSelectID(string id)
        {
            try
            {
                rootRestaurantes = new List<RootRestaurantes>();
                Uri url = new Uri($"https://super-mini-market.herokuapp.com/api/get-restaurantes/{id}");
                WebClient client = new WebClient();
                var data = await client.DownloadStringTaskAsync(url);
                dynamic Datos = JsonConvert.DeserializeObject(data)!;
                foreach (var i in Datos.data)
                {
                    var datos = new RootRestaurantes
                    {
                        IdRestaurante = i.IdRestaurante,
                        Nombre = i.Nombre,
                        Telefono = i.Telefono,
                        Direccion = i.Direccion,
                        Foto = i.Foto,
                        Hora_apertura = i.Hora_apertura,
                        Hora_cierre = i.Hora_cierre,
                        Dias_laborables = i.Dias_laborables
                    };
                    rootRestaurantes.Add(datos);
                }
                return rootRestaurantes;

            }
            catch (Exception)
            {

                throw;
            }
        }

        public Task<dynamic> Update(string id, string objeto)
        {
            throw new NotImplementedException();
        }
    }
}
