﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Fm.Modelo;
using Newtonsoft.Json;

namespace Fm.Data
{
    public class UsuariosCRUD: ICRUGGlobal
    {
        List<RegistroUsuario> rootUsuarios = new List<RegistroUsuario>();

        public async Task<dynamic> Create(string objeto)
        {
            string id = "3";
            Uri url = new Uri($"https://super-mini-market.herokuapp.com/api/Registro_Admins/{id}");
            WebClient client = new WebClient();
            var data = await client.UploadStringTaskAsync(url, objeto);
            dynamic Editable = JsonConvert.DeserializeObject(data);
            return Editable;
        }

        public async Task<dynamic> Delete(string jsonString)
        {
            Uri url = new Uri("https://super-mini-market.herokuapp.com/api/Borrar_Usuarios");
            WebClient client = new WebClient();
            var data = await client.UploadStringTaskAsync(url, jsonString);
            dynamic Editable = JsonConvert.DeserializeObject(data);
            return Editable;
        }

        public async Task<List<RegistroUsuario>> GetSelect()
        {
            try
            {
                rootUsuarios = new List<RegistroUsuario>(); 
                Uri url = new Uri("https://super-mini-market.herokuapp.com/api/Mostrar_Usuarios");
                WebClient client = new WebClient();
                var data = await client.DownloadStringTaskAsync(url);
                dynamic Datos = JsonConvert.DeserializeObject(data);
                foreach (var i in Datos)
                {
                    var dat = new RegistroUsuario
                    {
                      IdUsuario = i.IdUsuario,
                      Nombre = i.Nombre_Usuario,
                      Apellido = i.Apellido_Usuario,
                      Fecha_Nacimiento = i.Fecha_Nacimiento,
                      Correo = i.Correo,
                      Contraseña = i.Contraseña,
                      Rol = i.Rol
                    };
                    rootUsuarios.Add(dat);
                }
                return rootUsuarios;

            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<dynamic> Update(string Rol, string objeto)
        {
            string myUrl = "https://super-mini-market.herokuapp.com/api/Modificar_Usuarios/" + Rol;
            Uri url = new Uri(myUrl);
            WebClient client = new WebClient();
            var data = await client.UploadStringTaskAsync(url, objeto);
            dynamic Editable = JsonConvert.DeserializeObject(data)!;
            return Editable;
        }
    }
}
