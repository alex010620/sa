﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Fm.Data
{
    public class DataClientHome
    {
      public async Task<dynamic> Slidermanagement()
        {

            try
            {
                Uri url = new Uri("https://super-mini-market.herokuapp.com/api/Mostrar_Todos_Slides");
                WebClient client = new WebClient();
                var data = await client.DownloadStringTaskAsync(url);
                dynamic sliderData = JsonConvert.DeserializeObject(data);
                return sliderData;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
