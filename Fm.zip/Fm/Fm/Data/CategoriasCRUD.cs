﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Fm.Modelo
{
    public class CategoriasCRUD : ICRUGGlobal
    {
        List<RootCategoria> rootCategorias = new List<RootCategoria>();
        public async Task<dynamic> Create(string objeto)
        {
            Uri url = new Uri("https://super-mini-market.herokuapp.com/api/Registro_Categorias");
            WebClient client = new WebClient();
            var data = await client.UploadStringTaskAsync(url, objeto);
            dynamic valor = JsonConvert.DeserializeObject(data);
            return valor;
        }

        public Task<dynamic> Delete(string id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<RootCategoria>> GetSelect()
        {
            try
            {
                rootCategorias = new List<RootCategoria>();
                Uri url = new Uri("https://super-mini-market.herokuapp.com/api/Mostrar_Todas_Categoria");
                WebClient client = new WebClient();
                var data = await client.DownloadStringTaskAsync(url);
                dynamic Datos = JsonConvert.DeserializeObject(data);
                foreach (var i in Datos)
                {
                    var dat = new RootCategoria
                    {
                        IdCategoria = i.IdCategoria,
                        Nombre_categoria = i.Nombre_Categoria
                    };
                    rootCategorias.Add(dat);
                    
                }
                return rootCategorias;

            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<dynamic> Update(string id, string objeto)
        {
            Uri url = new Uri($"https://super-mini-market.herokuapp.com/api/Actualizar_Categoria/{id}");
            WebClient client = new WebClient();
            var data = await client.UploadStringTaskAsync(url,objeto);
            dynamic Datos = JsonConvert.DeserializeObject(data);
            return Datos;
        }
    }
}
