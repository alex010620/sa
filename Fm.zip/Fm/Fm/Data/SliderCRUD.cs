﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Fm.Modelo;
using Newtonsoft.Json;

namespace Fm.Data
{
    public class SliderCRUD : ICRUGGlobal
    {
        List<RootSlider> rootSliders = new List<RootSlider>();
        public async Task<List<RootSlider>> GetSelect()
        {
            try
            {
                Uri url = new Uri("https://super-mini-market.herokuapp.com/api/Mostrar_Todos_Slides");
                WebClient client = new WebClient();
                var data = await client.DownloadStringTaskAsync(url);
                dynamic Datos = JsonConvert.DeserializeObject(data);
                foreach (var i in Datos)
                {
                    var dat = new RootSlider
                    {
                        IdSlider = i.IdSlider,
                        Titulo = i.Titulo,
                        Recurso = i.Recurso
                    };
                    rootSliders.Add(dat);

                }
                return rootSliders;

            }
            catch (Exception)
            {

                throw;
            }
        }
        public Task<dynamic> Create(string objeto)
        {
            throw new NotImplementedException();
        }

        public Task<dynamic> Delete(string id)
        {
            throw new NotImplementedException();
        }

        public Task<dynamic> Update(string id, string objeto)
        {
            throw new NotImplementedException();
        }
    }
}
