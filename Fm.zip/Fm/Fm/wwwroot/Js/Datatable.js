function initializeDataTable(table) {
  $(document).ready(function () {
    $(table).DataTable();
  });
}